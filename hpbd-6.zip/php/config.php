<?php 
	define('HOSTNAME', 'localhost');
	define('USERNAME', 'root');
	define('PASSWORD', 'admin123');
	define('DBNAME', 'hpbd_');
?>